== Tested browser:
	- Chrome Version 30.0.1599.101 m
	- Firefox 25.0
	- Safari 5.1.7 (drag and drop works on Mac, not on Windows)
	- IE9
	- IE10


== Due to Chrome's same origin policy (on ajax), the app does not work in Chrome in local file system.

== Sorting by genre is based on the assumption that the number of gneres is equal to the number of shelves.


== implemented features:
1. Display all Meta data next to each book
2. Display shelf name as heading for each shelf
3. Be able to drag and drop books from one shelf to another
4. Add UI to organize each shelf by book genre. Each shelf should contain only books of one genre.
5. Add form for adding books following the same format as the sample data.
6. Add functionality to remove a book, use any method you prefer.




